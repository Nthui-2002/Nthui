<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" href="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Footer</title>
       <!--Boostrap CDN -->
       <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">

</head>
<body>
  

<div class="mt-5 fs-5 font-monospace text-center">
<p class="fixed-bottom text-white bg-danger py-2 mb-0"> 2025 Coding with @Nthui </p>
</div>

</body>
</html>