<?php
if (isset($_GET['ID'])) {
    $Id = $_GET['ID'];
    
    $con = mysqli_connect('localhost', 'root', '', 'ecommerce');
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $query = "DELETE FROM tblproduct WHERE Id = $Id";
    if (mysqli_query($con, $query)) {
        header("Location: index.php"); // or your actual product list page
        exit();
    } else {
        echo "Error deleting product: " . mysqli_error($con);
    }
} else {
    echo "Error: ID parameter missing.";
}
?>

